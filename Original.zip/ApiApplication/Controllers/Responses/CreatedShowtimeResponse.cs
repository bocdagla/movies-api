﻿namespace ApiApplication.Controllers.Responses
{
    public class CreatedShowtimeResponse
    {
        public int Id { get; set; }
    }
}
