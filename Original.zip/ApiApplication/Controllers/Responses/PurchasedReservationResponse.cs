﻿using System;

namespace ApiApplication.Controllers.Responses
{
    public class PurchasedReservationResponse
    {
        public Guid ReservationId { get; set; }
    }
}
