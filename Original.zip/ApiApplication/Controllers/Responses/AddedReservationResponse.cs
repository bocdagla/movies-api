﻿using System;

namespace ApiApplication.Controllers.Responses
{
    public class AddedReservationResponse
    {
        public Guid ReservationId { get; set; }
    }
}
