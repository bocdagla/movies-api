﻿namespace ApiApplication.ApiClients.Response
{
    public class MovieError
    {
        public int Code { get; set; }
        public string Message { get; set; }
    }
}